del "C:\New Mr.Son"\Code\mc.se

copy .\0\mc.se "C:\New Mr.Son"\Code\
