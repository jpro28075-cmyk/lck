ping localhost -n 5
cd C:\New Mr.Son
start  MrSon